//
//  settingView.swift
//  BrokeToBillionaire
//
//  Created by Bobby Dexter Wiles Jr. on 9/14/21.
//

import SwiftUI

struct settingView: View {
    @Binding var showSettingView: Bool
    
    var body: some View {
        NavigationView {
            ZStack{
                VStack {
                    Text("List of settings here")
                    Button(action: {
                        UserDefaults.standard.set(0, forKey: "Money")
                    }, label: {
                        ZStack {
                            Rectangle()
                                .foregroundColor(.black)
                            Text("RESET COINS")
                        }
                        .frame(width: 100, height: 50)
                    })
                    
                    Button(action: {
                        PlayerData().setMoney(amount: 100000000)
                    }, label: {
                        ZStack {
                            Rectangle()
                                .foregroundColor(.black)
                            Text("set money to 100,000,000")
                        }
                        .frame(width: 200, height: 100)
                    })
                    
                }
            }
            .navigationBarTitle(Text("Settings"), displayMode: .inline)
                .navigationBarItems(trailing: Button(action: {
                    self.showSettingView = false
                }) {
                    Text("Done").bold()
                })
            }
    }
}

