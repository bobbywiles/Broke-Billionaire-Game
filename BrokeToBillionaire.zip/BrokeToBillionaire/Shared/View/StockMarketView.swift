//
//  StockMarketView.swift
//  BrokeToBillionaire
//
//  Created by Bobby Dexter Wiles Jr. on 9/1/21.
//

import SwiftUI

struct StockMarketView: View {
    
    @ObservedObject var StockMarketData: StockMarketData
    @Environment(\.presentationMode) var presentationMode
    @State public var isEditing = false
    @State private var showPopUp = false
    
    let screenWidth = ContentView().screenRect.size.width
    let screenHeight = ContentView().screenRect.size.height
    
    let timer = Timer.publish(every: 0.125, on: .main, in: .common).autoconnect()
    let timer2 = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    @State public var coins = PlayerData().getMoney()
    
    func update(){
        coins = UserDefaults.standard.integer(forKey: "Money")
    }
    
    
    var body: some View {
        
        ZStack {
            VStack {
                
                ZStack {
                    Rectangle()
                        .frame(width: screenWidth, height: screenHeight/2.5, alignment: .center)
                    ForEach(0..<StockMarketData.xValue.count, id:\.self) { count in
                        Rectangle()
                            .border(Color.gray, width: 5)
                            .position(x: CGFloat(StockMarketData.xValue[count]), y: screenHeight/5)
                            .foregroundColor(.blue)
                            .frame(width: screenWidth/10, height: CGFloat(StockMarketData.heightValue[count]), alignment: .center)
                    }.padding(.trailing, screenWidth/1.25)
                        
                }
                
                
                Spacer()
                
                
                Group {
                    Text("Coins: \(coins)")
                        .padding(.bottom,20)
                    Text("Stock Own Limit: \(StockMarketData.maxOwnStockAmount)")
                    Text("Owned Stock: \(StockMarketData.ownedStockAmount)")
                    Text("Price Per Stock: \(StockMarketData.stockValue) Coins")
                    Spacer()
                    Text("Upgrades Owned \(StockMarketData.stockStoreageUpgradeCount)")
                    Button(action: {
                        StockMarketData.upgradeStockStorage()
                    }, label: {
                        VStack {
                            Text("Upgrade Storage (+500)")
                            Text("Cost: \(StockMarketData.maxOwnStockAmount*30)")
                        }
                    })
                    
                    
                    Button(action: {
                        StockMarketData.stockStoreageUpgradeCount = 0
                        UserDefaults.standard.set(0, forKey: "stockUpgrade")
                    }, label: {
                        Text("RESET STORAGE")
                    }).padding(.top, 30)
                    
                    
                    /*Button(action: {
                        self.showPopUp = true
                    }, label: {
                        Text("popup")
                    }).alert(isPresented: $showPopUp) {
                        Alert(title: Text("TITLE"))
                    }
                    .padding(.top,30)*/
                    
                    
                }
                
                Spacer()
                Spacer()
                
                HStack {
                    
                    VStack {
                        Text("Order: \(Int(StockMarketData.sliderOrderStock)) Stocks")
                        Text("Price: \(Int(StockMarketData.sliderOrderStock) * StockMarketData.stockValue)")
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 25, style: .continuous)
                                .frame(width: screenWidth/2.5, height: screenHeight/17.92)
                                .foregroundColor(.clear)
                            
                            RoundedRectangle(cornerRadius: 25, style: .continuous)
                                .frame(width: screenWidth/2.4, height: screenHeight/25)
                                .foregroundColor(.blue)
                            
                            
                            Slider(value: $StockMarketData.sliderOrderStock, in: 0...StockMarketData.getBuySliderAmount(), step: 1, onEditingChanged: {
                                editing in isEditing = editing
                            })
                            .frame(width: screenWidth/2.5, height: screenHeight/17.92)
                            
                            
                        }
                        
                        ZStack {
                            
                            Button(action: {
                                //do nothing
                            }, label: {
                                Text("         ")
                                    .font(.title)
                            })
                            if StockMarketData.displayBuyButton {
                                
                                Button(action: {
                                    StockMarketData.buyStock()
                                }, label: {
                                    Text("Buy Stock")
                                        .font(.title)
                                })
                                
                            }
                        }
                        
                        
                    }
                    
                    VStack {
                        Text("Sell: \(Int(StockMarketData.sliderSellStock)) Stocks")
                        Text("Price: \(Int(StockMarketData.sliderSellStock) * StockMarketData.stockValue)")
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 25, style: .continuous)
                                .frame(width: screenWidth/2.5, height: screenHeight/17.92)
                                .foregroundColor(.clear)
                            
                            if StockMarketData.displaySellBar {
                                
                                RoundedRectangle(cornerRadius: 25, style: .continuous)
                                    .frame(width: screenWidth/2.4, height: screenHeight/25)
                                    .foregroundColor(.blue)
                                
                                Slider(value: $StockMarketData.sliderSellStock, in: 0...(StockMarketData.getSellSliderAmount()), step: 1, onEditingChanged: {
                                    editing in isEditing = editing
                                })
                                .frame(width: screenWidth/2.5, height: screenHeight/17.92)
                            }
                            
                            
                            
                        }
                        
                        ZStack {
                            
                            Button(action: {
                                
                            }, label: {
                                Text("          ")
                                    .font(.title)
                            })
                            
                            if StockMarketData.displaySellButton {
                                Button(action: {
                                    StockMarketData.sellStock()
                                }, label: {
                                    Text("Sell Stock")
                                        .font(.title)
                                })
                            }
                        }
                        
                        
                        
                    }
                    
                    
                }
                
                Spacer()
            }
            .onReceive(timer){ time in StockMarketData.update2()}
            .onReceive(timer){ time in self.update()}
            .onReceive(timer2){ time in StockMarketData.update()}
            
        }
        .ignoresSafeArea()
        
    }
    
    
    
}

struct StockMarketView_Previews: PreviewProvider {
    static var previews: some View {
        StockMarketView(StockMarketData: StockMarketData())
    }
}
