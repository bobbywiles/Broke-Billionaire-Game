//
//  BlackjackGameView.swift
//  GambleMan
//
//  Created by Bobby Dexter Wiles Jr. on 8/17/21.
//

import SwiftUI

struct BlackjackGameView: View {
    
    @ObservedObject var BlackjackData: BlackjackData
    @Environment(\.presentationMode) var presentationMode
    @State public var isEditing = false
    
    let screenWidth = ContentView().screenRect.size.width
    let screenHeight = ContentView().screenRect.size.height
    
    let timer = Timer.publish(every: 0.125, on: .main, in: .common).autoconnect()
    
    var body: some View {
        HStack{
            Image("backgroundImage")
                .resizable()
                .ignoresSafeArea()
                .overlay(
                    ZStack{
                        VStack{
                            HStack{
                                Spacer()
                                
                                Image("coinImage")
                                    .resizable()
                                    .frame(width: 30, height: 30, alignment: .center)
                                
                                Text("\(PlayerData().getMoney())")
                                    .font(.largeTitle)
                                    .foregroundColor(.white)
                                
                            }
                            .padding(.trailing, 40)
                            .padding(.top, screenHeight/10.2)
                            
                            
                            HStack{
                                Spacer()
                                
                                VStack {
                                    Text("Won")
                                        .font(.title3)
                                        .padding(.leading, 25)
                                        .foregroundColor(.white)
                                    
                                    HStack {
                                        Image("coinImage")
                                            .resizable()
                                            .frame(width: 20, height: 20, alignment: .center)
                                        
                                        Text("\(BlackjackData.winningAmount)")
                                            .font(.title3)
                                            .foregroundColor(.white)
                                    }.padding(.top, -5)
                                }
                                
                            }
                            .padding(.top,10)
                            .padding(.trailing, 40)
                            
                            
                            Spacer()
                        }
                        Circle()
                            .frame(width: screenWidth)
                            .foregroundColor(.black)
                        Circle()
                            .frame(width: screenWidth-20)
                            .foregroundColor(.green)
                        Group{
                            
                            Group{
                                Image("pokerCoinImage")
                                    .resizable()
                                    .frame(width: screenHeight/30, height: screenHeight/30)
                                    .padding(.leading, 150)
                                Image("pokerCoinImage")
                                    .resizable()
                                    .frame(width: screenHeight/30, height: screenHeight/30)
                                    .padding(.leading, 80)
                                Image("pokerCoinImage")
                                    .resizable()
                                    .frame(width: screenHeight/30, height: screenHeight/30)
                                    .padding(.leading, 115)
                                    .padding(.top, 60)
                            }
                            
                            HStack{
                                VStack{
                                    Image("cardBack(1x)2")
                                        .resizable()
                                        .frame(width: screenWidth/5.175, height: screenHeight/14.9333)
                                        .padding(.leading, 25)
                                        .padding(.bottom, 10)
                                        .foregroundColor(.black)
                                    Image("cardBack(1x)2")
                                        .resizable()
                                        .frame(width: screenWidth/5.175, height: screenHeight/14.9333)
                                        .padding(.leading, 25)
                                        .padding(.top, 10)
                                        .foregroundColor(.black)
                                    
                                }
                                Spacer()
                            }
                            VStack{
                                Spacer()
                                
                                ZStack{
                                    Rectangle()
                                        .foregroundColor(.black)
                                        .frame(width: screenWidth/1.6, height: screenHeight/8, alignment: .center)
                                        .padding(.bottom, screenHeight/8.145)
                                    
                                    Rectangle()
                                        .foregroundColor(Color(red: 169/255, green: 106/255, blue: 16/255, opacity: 1.0))
                                        .frame(width: screenWidth/1.656, height: screenHeight/8.96, alignment: .center)
                                        .padding(.bottom, screenHeight/8.145)
                                    
                                    HStack{
                                        ForEach(0..<BlackjackData.dealerCardsStringArray.count, id:\.self) { imageIdx in
                                            Image(BlackjackData.dealerCardsStringArray[imageIdx])
                                                   .resizable()
                                                .frame(width: screenWidth/6.9, height: screenHeight/11.2)
                                                .padding(.trailing,10)
                                                
                                                }
                                    }
                                    .padding(.bottom,screenHeight/8.145)
                                    
                                }
                                
                                ZStack{
                                    Rectangle()
                                        .foregroundColor(.black)
                                        .frame(width: screenWidth/1.6, height: screenHeight/8, alignment: .center)
                                        .padding(.top, 110)
                                    Rectangle()
                                        .foregroundColor(Color(red: 169/255, green: 106/255, blue: 16/255, opacity: 1.0))
                                        .frame(width: screenWidth/1.656, height: screenHeight/8.96, alignment: .center)
                                        .padding(.top, 110)
                                    HStack{
                                        ForEach(0..<BlackjackData.playerCardsStringArray.count, id:\.self) { imageIdx in
                                            Image(BlackjackData.playerCardsStringArray[imageIdx])
                                                   .resizable()
                                                .frame(width: screenWidth/6.5, height: screenHeight/10)
                                                .padding(.trailing,-30)
                                                .padding(.top, screenHeight/8.145)
                                                
                                                }
                                    }.padding(.leading, -25)
                                    
                                }
                                
                                
                                Spacer()
                            }
                            VStack{
                                Spacer()
                                HStack{
                                    
                                    if BlackjackData.displayHit {
                                        Button(action: {
                                            BlackjackData.hit()
                                        }, label: {
                                            Text("Hit")
                                                .foregroundColor(.white)
                                                .font(.largeTitle)
                                                .frame(width: screenWidth/3.312, height: screenHeight/44.8)
                                        })
                                        .buttonStyle(GradientButtonStyle2())
                                        .padding(.leading, 25)
                                    }
                                    
                                    Spacer()
                                    
                                    if BlackjackData.displayDone {
                                        Button(action: {
                                            BlackjackData.done()
                                        }, label: {
                                            Text("Done")
                                                .foregroundColor(.white)
                                                .font(.largeTitle)
                                                .frame(width: screenWidth/3.312, height: screenHeight/44.8)
                                        })
                                        .buttonStyle(GradientButtonStyle2())
                                        .padding(.trailing, 25)
                                    }
                                    
                                    
                                }.frame(width: screenWidth/1.035, height: screenHeight/11.946)
                                
                                
                            }.padding(.bottom, screenHeight/35.84)
                            
                            VStack{
                                Group{
                                    Spacer()
                                    Spacer()
                                    Spacer()
                                    Spacer()
                                    Text("Bet: \(Int(BlackjackData.setBetAmount)) Coins")
                                        .font(.title3)
                                        .foregroundColor(.black)
                                        .multilineTextAlignment(.leading)
                                }
                                
                                Spacer()
                                Spacer()
                                Spacer()
                                //BlackjackData.getSlideBetAmount() full realse use
                                //1700 testing use
                                HStack{
                                    
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                                            .frame(width: screenWidth/2, height: screenHeight/25)
                                            .foregroundColor(.blue)
                                            .padding(.leading, 40)
                                        
                                        Slider(value: $BlackjackData.betAmount, in: 0...BlackjackData.getSlideBetAmount(), step: 1, onEditingChanged: {
                                            editing in isEditing = editing
                                        })
                                        .frame(width: screenWidth/2.07, height: screenHeight/17.92)
                                        .padding(.leading, 40)
                                    }
                                    
                                    Spacer()
                                    
                                    if BlackjackData.placeBetButtonText {
                                        Button(action: {
                                            BlackjackData.placeBet()
                                        }, label: {
                                            Text("Place Bet")
                                                .frame(width: screenWidth/5.52, height: screenHeight/59.733)
                                                
                                        })
                                        .buttonStyle(GradientButtonStyle2())
                                        .padding(.trailing, 40)
                                    }
                                    
                                    
                                    
                                }.padding(.bottom,screenHeight/29.866)
                                Spacer()
                                
                            }
                        }
                    }
                    .onReceive(timer){ time in BlackjackData.updateBlackjack()}
                )
        }
        
        .navigationBarBackButtonHidden(false)
        /*.navigationBarItems(leading: MyBackButton(lable: "Back"){
            self.presentationMode.wrappedValue.dismiss()
        })*/
        .ignoresSafeArea()
    }
}

struct BlackjackGameView_Previews: PreviewProvider {
    static var previews: some View {
        BlackjackGameView(BlackjackData: BlackjackData())
    }
}

