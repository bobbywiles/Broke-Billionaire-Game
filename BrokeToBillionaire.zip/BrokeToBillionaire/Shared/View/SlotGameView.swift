//
//  SlotGameView.swift
//  GambleMan (iOS)
//
//  Created by Bobby Dexter Wiles Jr. on 8/17/21.
//

import SwiftUI

struct SlotGameView: View {
    
    @State private var angle: Double = 0
    @ObservedObject var SlotData: SlotData
    @Environment(\.presentationMode) var presentationMode
    
    let timer = Timer.publish(every: 0.125, on: .current, in: .common).autoconnect()
    @State public var displayCost = 10
    
    var body: some View {
        HStack {
            Image("backgroundImage")
                .resizable()
                .ignoresSafeArea()
                .overlay(
                    ZStack{
                        VStack{
                            HStack{
                                Spacer()
                                Image("coinImage")
                                    .resizable()
                                    .frame(width: 30, height: 30, alignment: .center)
                                Text("\(PlayerData().getMoney())")
                                    .font(.title)
                                    .padding(.trailing, 40)
                                    .foregroundColor(Color.black)
                            }
                            
                            HStack {
                                Spacer()
                                Text("You Won: \(SlotData.SlotWinningAmount) Coins")
                                    .padding(.trailing, 40)
                            }
                            
                            Spacer()
                            
                            
                            HStack{
                                ZStack{
                                    RoundedRectangle(cornerRadius: 25.0)
                                        .fill(Color.white)
                                        .frame(width: 100.0, height: 150.0)
                                        .padding(10)
                                    Text("\(SlotData.SlotBox1)")
                                        .font(.largeTitle)
                                        .foregroundColor(Color.black)
                                }
                                ZStack{
                                    RoundedRectangle(cornerRadius: 25.0)
                                        .fill(Color.white)
                                        .frame(width: 100.0, height: 150.0)
                                        .padding(10)
                                    Text("\(SlotData.SlotBox2)")
                                        .font(.largeTitle)
                                        .foregroundColor(Color.black)
                                }
                                ZStack{
                                    RoundedRectangle(cornerRadius: 25.0)
                                        .fill(Color.white)
                                        .frame(width: 100.0, height: 150.0)
                                        .padding(10)
                                    Text("\(SlotData.SlotBox3)")
                                        .font(.largeTitle)
                                        .foregroundColor(Color.black)
                                        
                                }
                            }
                            
                            Spacer()
                            Spacer()
                            
                            ZStack{
                                Button(action: {
                                    SlotData.SlotSpin()
                                    angle += (SlotData.spinDegree)
                                }, label: {
                                    Text(" \(displayCost) Coins - Spin ")
                                        .onReceive(timer, perform: { _ in
                                            self.displayCost = Int(pow(10.0, Double(SlotData.scale)))
                                        })
                                        .font(.largeTitle)
                                })
                                .rotationEffect(.degrees(angle))
                                .animation(.spring(), value: angle)
                                .buttonStyle(GradientButtonStyle2())
                                .shadow(radius: 10)
                                
                            }
                            
                            Spacer()
                        }
                    }
                    
                )
        }
        .onReceive(timer){ time in SlotData.updateSlot()}
        .navigationTitle("Slots")
    }
}

struct SlotGameView_Previews: PreviewProvider {
    static var previews: some View {
        SlotGameView(SlotData: SlotData())
    }
}

