//
//  achievmentView.swift
//  BrokeToBillionaire
//
//  Created by Bobby Dexter Wiles Jr. on 9/14/21.
//

import SwiftUI

struct achievmentView: View {
    @Binding var showAchievmentView: Bool
    
    
    var body: some View {
        NavigationView {
            ZStack{
                VStack {
                    Text("List of achievments here")
                    
                }
            }
            .navigationBarTitle(Text("Achievments"), displayMode: .inline)
                .navigationBarItems(trailing: Button(action: {
                    self.showAchievmentView = false
                }) {
                    Text("Done").bold()
                })
            }
    }
}

