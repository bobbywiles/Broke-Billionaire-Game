//
//  ContentView.swift
//  Shared
//
//  Created by Bobby Dexter Wiles Jr. on 8/17/21.
//

import SwiftUI

struct NavigationViewOptions {
    @ObservedObject var slotData = SlotData()
    @ObservedObject var blackjackData = BlackjackData()
    @ObservedObject var playerData = PlayerData()
    @ObservedObject var begData = BegData()
    @ObservedObject var stockMarketData = StockMarketData()
    
    enum OptionType { case testView, slotGame, blackjackGame, option3, beg, stocks}
    typealias Option = (id: UUID, value: String, type: Self.OptionType)
    static var options: [Option] = [
        (UUID(), "Beg", .beg),
        (UUID(), "Slots", .slotGame),
        (UUID(), "BrokeJack", .blackjackGame),
        (UUID(), "Stocks", .stocks),
        (UUID(), "Store", .option3),
        
    ]

    static func buildView(for option: Option) -> some View {
        switch option.type {
        case .testView:
            return AnyView(EmptyView())
        case .slotGame:
            return AnyView(SlotGameView(SlotData: SlotData()))
        case .blackjackGame:
            return AnyView(BlackjackGameView(BlackjackData: BlackjackData()))
        case .option3:
            return AnyView(EmptyView())
        case .beg:
            return AnyView(BegView(BegData: BegData()))
        case .stocks:
            return AnyView(StockMarketView(StockMarketData: StockMarketData()))
        
        }
        
    }
}

func irsUpdater() {
    ContentView().showIRSView = true
}


struct ContentView: View {
    @State private var selectedOption: NavigationViewOptions.Option = (id:UUID(),"",.slotGame)
    @State private var showDetail: Bool = false
    @State public var MoneyText = UserDefaults.standard.integer(forKey: "Money")
    @State private var angle: Double = 0
    @State var showSettingView = false
    @State var showAchievmentView = false
    @State var showIRSView = false
    @State var firstViewTrigger = 0
    
    @ObservedObject var slotData = SlotData()
    @ObservedObject var blackjackData = BlackjackData()
    @ObservedObject var playerData = PlayerData()
    @ObservedObject var begData = BegData()
    
    let timer = Timer.publish(every: 0.01, on: .current, in: .common).autoconnect()
    let screenRect = UIScreen.main.bounds
    
    var body: some View {
        
        NavigationView{
            Image("backgroundImage2")
                .resizable()
                .ignoresSafeArea()
                .overlay(
                    ZStack{
                        VStack{
                            Text("Broke Billionaire")
                                .font(.largeTitle)
                                .foregroundColor(.white)
                                .position(x: screenRect.width/2, y: CGFloat(playerData.titleY))
                            
                            //playerData.isStart
                            
                            if (playerData.isStart) {
                                Group {
                                    HStack {
                                        ZStack {
                                            Circle()
                                                .foregroundColor(Color.white)
                                                .frame(width: 30, height: 30)
                                            Image("coinImage")
                                                .resizable()
                                                .frame(width: 30, height: 30, alignment: .center)
                                        }
                                        
                                        Text("\(self.MoneyText)").onAppear(perform: {
                                            self.MoneyText = UserDefaults.standard.integer(forKey: "Money")
                                            
                                            if ((UserDefaults.standard.bool(forKey: "IRS")) && (firstViewTrigger != 0) && (MoneyText > 100)) {
                                                playerData.setMoney(amount: 0)
                                                self.MoneyText = UserDefaults.standard.integer(forKey: "Money")
                                                showIRSView = true
                                                UserDefaults.standard.set(false, forKey: "IRS")
                                            }
                                            self.firstViewTrigger = 1
                                        })
                                        .font(.title2)
                                        .foregroundColor(.white)
                                    }
                                    .position(x: screenRect.width/2)
                                    
                                    GeometryReader { fullView in
                                        
                                        ScrollView(.horizontal, showsIndicators: false){
                                            
                                            HStack (alignment: .center, spacing: -150) {
                                                ForEach(NavigationViewOptions.options, id: \.id) {
                                                    
                                                    option in
                                                    
                                                    GeometryReader {
                                                        
                                                        geo in
                                                        ZStack{
                                                            RoundedRectangle(cornerRadius: 50, style: .continuous)
                                                                .fill(Color.blue)
                                                                .frame(width: fullView.size.width/1.5, height: fullView.size.height/1.15)
                                                                .onTapGesture {
                                                                    selectedOption = option
                                                                    showDetail = true
                                                                    
                                                                }
                                                            
                                                            Text(option.value)
                                                                .font(.title)
                                                                .padding(.vertical, 10) //10
                                                                .foregroundColor(.white)
                                                                .onTapGesture {
                                                                    selectedOption = option
                                                                    showDetail = true
                                                                    
                                                                }
                                                                
                                                        }
                                                        .frame(width: fullView.size.width/2, height: fullView.size.height/5, alignment: .center)
                                                        .shadow(color: Color.black.opacity(0.5), radius: 20, x: 0, y: 0)
                                                        .rotation3DEffect(.degrees(Double(geo.frame(in: .global).minX - (fullView.size.width/4)) / -10), axis: (x: 0, y: 1.0, z: 0))
                                                        
                                                        
                                                        
                                                        
                                                    }.frame(width: fullView.size.width, height: fullView.size.height)
                                                    .padding(.top, 150)
                                                    
                                                }
                                            }.padding(.leading, 100)
                                        
                                        }
                                    
                                        NavigationLink("", destination: NavigationViewOptions.buildView(for: selectedOption), isActive: $showDetail)
                                                                .opacity(0)
                                        
                                    }
                                    .frame(width: screenRect.width, height: screenRect.height/2.98)
                                    .position(x: screenRect.width/2, y: screenRect.height/(-55))
                                    
                                    //player character image
                                    Image("coinImage")
                                        .resizable()
                                        .frame(width: 100, height: 200, alignment: .center)
                                        .padding(.top, 300)
                                        .hidden() //next update release
                                    
                                    HStack {
                                        ZStack {
                                            
                                            Button(action: {
                                                self.showSettingView.toggle()
                                            }, label: {
                                                ZStack {
                                                    Rectangle()
                                                        .foregroundColor(.black)
                                                        .frame(width: 120, height: 50)
                                                    Text("Settings")
                                                }
                                            })
                                            
                                        }.position(x: 75, y: screenRect.height/3.5)
                                        
                                        ZStack {
                                            Button(action: {
                                                self.showAchievmentView.toggle()
                                            }, label: {
                                                ZStack {
                                                    Rectangle()
                                                        .foregroundColor(.black)
                                                        .frame(width: 120, height: 50)
                                                    Text("Achievments")
                                                }
                                            })
                                            
                                        }.position(x: screenRect.width/2-75, y: screenRect.height/3.5)
                                    }//.hidden() //next update release
                                    
                                    
                                }.position(x: screenRect.width/2, y: screenRect.height/(-8.96))
                                
                            } else {
                                Button(action: {
                                    angle -= 360
                                    playerData.startGrame()
                                        
                                }, label: {
                                    ZStack {
                                        Circle()
                                            .fill(Color.gray)
                                            .frame(width: 100, height: 100)
                                        Image(systemName: "chevron.right")
                                            .resizable()
                                            .rotationEffect(.degrees(angle))
                                            .animation(.spring(), value: angle)
                                            .foregroundColor(.white)
                                            .frame(width: 50, height: 50)
                                    }
                                    .position(x: screenRect.width/2 - CGFloat(playerData.moveButton), y: 0)
                                        
                                })
                                .onReceive(timer){ time in
                                    if (!playerData.isStart) {
                                        playerData.moveTitle()
                                    }
                                }
                            }
                            
                            Spacer()
                            Spacer()
                            
                        }
                    }
                    
                )
        }.sheet(isPresented: $showSettingView) {
            settingView(showSettingView: self.$showSettingView)
        }
        .sheet(isPresented: $showAchievmentView) {
            achievmentView(showAchievmentView: self.$showAchievmentView)
        }
        .sheet(isPresented: $showIRSView) {
            IRSView(showIRSView: self.$showIRSView)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
        }
    }
}

struct GradientButtonStyle2: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .foregroundColor(Color.white)
            .padding()
            .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.blue]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(10)
    }
}

struct MyBackButton: View {
    let lable: String
    let closure: () -> ()
    
    var body: some View {
        Button(action: { self.closure() }) {
            HStack {
                Image(systemName: "arrow.left.circle")
                    .foregroundColor(.white)
                Text(lable)
                    .foregroundColor(.white)
            }
        }
    }
}
