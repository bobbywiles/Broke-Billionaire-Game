//
//  IRSView.swift
//  BrokeToBillionaire
//
//  Created by Bobby Dexter Wiles Jr. on 9/15/21.
//

import SwiftUI

struct IRSView: View {
    @Binding var showIRSView: Bool
    
    var body: some View {
        NavigationView {
            ZStack{
                VStack {
                    Text("Sorry to inform you that you have not been paying taxes for your winnings. All of your coins has been taken away for your wreckless actions.")
                    
                }
            }
            .navigationBarTitle(Text("IRS"), displayMode: .inline)
                .navigationBarItems(trailing: Button(action: {
                    self.showIRSView = false
                }) {
                    Text("Done").bold()
                })
            }
    }
}
