//
//  BegView.swift
//  BrokeToBillionaire
//
//  Created by Bobby Dexter Wiles Jr. on 8/26/21.
//

import SwiftUI

struct BegView: View {
    
    @ObservedObject var BegData: BegData
    @Environment(\.presentationMode) var presentationMode
    
    let screenWidth = ContentView().screenRect.size.width
    let screenHeight = ContentView().screenRect.size.height
    let peopleWidth =  CGFloat(30)
    let peopleHeight =  CGFloat(80)
    
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    @State public var coins = PlayerData().getMoney()
    
    func update() {
        self.coins = UserDefaults.standard.integer(forKey: "Money")
    }
    
    
    var body: some View {
        ZStack {
            
            VStack {
                
                Text("Coins: \(coins)")
                    .font(.largeTitle)
                
                Spacer()
                
                
                ZStack {
                        
                    
                    Rectangle()
                        .frame(width: screenWidth, height: 250, alignment: .center)
                        .foregroundColor(.gray)
                    
                    
                    Button (action: {
                        BegData.begPress()
                    }, label: {
                        Rectangle()
                    })
                    .frame(width: peopleWidth, height: peopleHeight, alignment: .center)
                    .position(x: CGFloat(BegData.human1[0]), y: CGFloat(BegData.human1[1]))
                    .foregroundColor(.black)
                    
                    
                    Button (action: {
                        BegData.begPress()
                    }, label: {
                        Rectangle()
                    })
                    .frame(width: peopleWidth, height: peopleHeight, alignment: .center)
                    .position(x: CGFloat(BegData.human2[0]), y: CGFloat(BegData.human2[1]))
                    .foregroundColor(.black)
                    
                    
                    Button (action: {
                        BegData.begPress()
                    }, label: {
                        Rectangle()
                    })
                    .frame(width: peopleWidth, height: peopleHeight, alignment: .center)
                    .position(x: CGFloat(BegData.human3[0]), y: CGFloat(BegData.human3[1]))
                    .foregroundColor(.black)
                    
                    Button (action: {
                        BegData.begPress()
                    }, label: {
                        Rectangle()
                    })
                    .frame(width: peopleWidth, height: peopleHeight, alignment: .center)
                    .position(x: CGFloat(BegData.human4[0]), y: CGFloat(BegData.human4[1]))
                    .foregroundColor(.black)
                    
                    
                }
                
                Spacer()
                
                
            }
        }.onReceive(timer) {
            time in self.update()
        }
        .onReceive(timer) {
            time in BegData.update()
        }
    }
}

struct BegView_Previews: PreviewProvider {
    static var previews: some View {
        BegView(BegData: BegData())
    }
}
