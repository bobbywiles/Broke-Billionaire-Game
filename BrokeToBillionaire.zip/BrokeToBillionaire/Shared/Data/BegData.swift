//
//  BegData.swift
//  BrokeToBillionaire
//
//  Created by Bobby Dexter Wiles Jr. on 8/26/21.
//

import Foundation


class BegData: ObservableObject {
    @Published public var human1: [Int] = [Int.random(in: -500 ... -440), Int.random(in: 200...400)]
    @Published public var human2: [Int] = [Int.random(in: -100 ... -40), Int.random(in: 200...400)]
    @Published public var human3: [Int] = [Int.random(in: 500 ... 600), Int.random(in: 200...400)]
    @Published public var human4: [Int] = [Int.random(in: 1000 ... 1050), Int.random(in: 200...400)]
    
    var begCount = 0
    
    var speed1 = Int.random(in: 8 ... 15)
    var speed2 = Int.random(in: 8 ... 15)
    var speed3 = Int.random(in: -15 ... -8)
    var speed4 = Int.random(in: -15 ... -8)
    
    func update() {
        human1[0] += speed1
        human2[0] += speed2
        human3[0] += speed3
        human4[0] += speed4
        
        if human1[0] >= 500 {
            human1[0] = Int.random(in: -500 ... -440)
            human1[1] = Int.random(in: 200...400)
            speed1 = Int.random(in: 8 ... 15)
        }
        
        if human2[0] >= 500 {
            human2[0] = Int.random(in: -100 ... -40)
            human2[1] = Int.random(in: 200...400)
            speed2 = Int.random(in: 8 ... 15)
        }
        if human3[0] <= -100 {
            human3[0] = Int.random(in: 500 ... 600)
            human3[1] = Int.random(in: 200...400)
            speed3 = Int.random(in: -15 ... -8)
        }
        if human4[0] <= -100 {
            human4[0] = Int.random(in: 1000 ... 1050)
            human4[1] = Int.random(in: 200...400)
            speed4 = Int.random(in: -15 ... -8)
        }
        
    }
    
    
    
    func begPress() {
        
        begCount += 1
        
        if begCount >= Int.random(in: 5...20) {
            
            PlayerData().setMoney(amount: (PlayerData().getMoney()+1))
            
            begCount = 0
            
        }
    }
}
