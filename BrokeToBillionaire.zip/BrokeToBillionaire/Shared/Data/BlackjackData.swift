//
//  BlackjackData.swift
//  GambleMan
//
//  Created by Bobby Dexter Wiles Jr. on 8/17/21.
//

import Foundation
import SwiftUI
import Combine

class BlackjackData: ObservableObject {
    
    @Published public var winningAmount = 0
    @Published public var betAmount = 0.0
    @Published public var setBetAmount = 0.0
    @Published public var placeBetButtonText = true
    @Published public var displayDone = false
    @Published public var displayHit = false
    @Published public var dealerFinalValue = 0
    @Published public var playerFinalValue = 0
    @Published public var dealerCardsStringArray: [String] = []
    @Published public var playerCardsStringArray: [String] = []
    @Published public var sizePadding = -25
    
    var isBetPlaced = false
    var hitCount = 0
    var win = false
    var playerCards: [Int] = []
    var dealerCards: [Int] = []
    var playerCardCounter = 0
    var canHit = false
    var alreadyDealerHit = false
    var counter = 0
    
    
    //run every 0.125 of a second
    func updateBlackjack(){
        
        //hide and show place button text
        if betAmount > 0 && betAmount <= Double(PlayerData().getMoney()) && !isBetPlaced {
            placeBetButtonText = true
        } else {
            placeBetButtonText = false
        }
        
        //set bet amount to the slider value
        if !isBetPlaced{
            setBetAmount = betAmount
        }
        
        //calc placer card value and recalc J,Q,K to value of 10 and add it all up
        for playerCard in playerCards {
            if playerCard >= 11 && playerCard <= 13 {
                playerFinalValue += 10
            } else if playerCard <= 10 {
                playerFinalValue += playerCard
            }
        }
        
        //check if player is over 21 and hide hit button if they are
        if playerFinalValue > 21 {
            playerFinalValue = 0
            displayHit = false
            canHit = false
        } else {
            if isBetPlaced {
                displayHit = true
                canHit = true
            }
            playerFinalValue = 0
        }
    }
    
    //place bet function call
    func placeBet(){
        //if bet can be valid then place
        if betAmount > 0 && betAmount <= Double(PlayerData().getMoney()){
            
            PlayerData().setMoney(amount: PlayerData().getMoney() - Int(setBetAmount))
            isBetPlaced = true
            canHit = true
            alreadyDealerHit = false
            winningAmount = 0
            dealerCardsStringArray.removeAll()
            dealerCardsStringArray = []
            playerCardsStringArray.removeAll()
            dealerCards.removeAll()
            playerCards.removeAll()
            
        }
    }
    
    //hit function call
    func hit(){
        var randomTestDealerDraw = 0
        
        //see if player cna hit check
        if isBetPlaced && canHit{
            if hitCount == 0 {
                
                //dealer draw 2 cards
                drawCardGen(arrayPick: 2)
                drawCardGen(arrayPick: 2)
                
                dealerCardsStringArray = ["cardBack(1x)", "cardBack(1x)"]
                
                displayDone = true
                
                //draw two cards
                drawCardGen(arrayPick: 1)
                drawCardGen(arrayPick: 1)
                hitCount+=1
            } else {
                //draw one card
                drawCardGen(arrayPick: 1)
                
                randomTestDealerDraw = Int.random(in: 0...10)
                
                if randomTestDealerDraw < 4 && !alreadyDealerHit {
                    drawCardGen(arrayPick: 2)
                    dealerCardsStringArray = ["cardBack(1x)", "cardBack(1x)", "cardBack(1x)"]
                    alreadyDealerHit = true
                }
                
                
            }
        }
    }
    
    //done button call
    func done(){
        
        //make sure they have some cards first
        if hitCount != 0 {
            
            //reset value counter
            dealerFinalValue = 0
            playerFinalValue = 0
            
            
            //add up dealer card values
            for dealerCard in dealerCards {
                if dealerCard >= 11 && dealerCard <= 13{
                    dealerFinalValue += 10
                } else if dealerCard <= 10{
                    dealerFinalValue += dealerCard
                }
            }
            
            //add up player card values
            for playerCard in playerCards {
                if playerCard >= 11 && playerCard <= 13 {
                    playerFinalValue += 10
                } else if playerCard <= 10 {
                    playerFinalValue += playerCard
                }
            }
            
            //if player is under 21 and higher than dealer they win check
            if playerFinalValue <= 21 {
                if dealerFinalValue <= playerFinalValue  || dealerFinalValue > 21{
                    win = true
                }
            }
            
            //print("Dealer Final Value: \(dealerFinalValue)")
            //print("Player Final Value: \(playerFinalValue)")
            //print(" ")
            
            //give out rewards and reset win value
            if win {
                winningAmount = (Int(setBetAmount) * 2)
                PlayerData().setMoney(amount: PlayerData().getMoney() + winningAmount)
                win = false
                
                if (winningAmount > 7500) {
                    counter += 1
                    
                    if (counter >= 3) {
                        UserDefaults.standard.set(true, forKey: "IRS")
                    }
                    
                } else {
                    counter -= 1
                }
                
            } else {
                counter -= 1
                
                if (counter <= -5) {
                    UserDefaults.standard.set(false, forKey: "IRS")
                }
                
            }
            
            //dealer card string array set up
            dealerCardsStringArray.removeAll()
            var counterCard = 1
            for dealerCard in dealerCards {
                if counterCard.isMultiple(of: 2) {
                    dealerCardsStringArray[(counterCard/2)-1] += "\(dealerCard)"
                } else {
                    dealerCardsStringArray.append("\(dealerCard)")
                }
                counterCard+=1
            }
 
            //reset values
            displayHit = false
            displayDone = false
            hitCount = 0
            betAmount = 0
            setBetAmount = 0
            isBetPlaced = false
            playerFinalValue = 0
            
        }
    }
    
    //generator that gets a card out of the deck
    func drawCardGen(arrayPick: Int){
        var cardValue = Int.random(in: 1...13)
        var isNotClearPlayer = true
        var isNotClearDealer = true
        var cardSet = Int.random(in: 20...23)
        var counterPlayer = 0
        var counterDealer = 0
        
        
        // doublication card check
        
        while isNotClearPlayer || isNotClearDealer {
            
            cardValue = Int.random(in: 1...13)
            cardSet = Int.random(in: 20...23)
            
            for playerCards in playerCards {
                
                if playerCards == cardValue {
                    counterPlayer += 1
                } else if playerCards == cardSet {
                    counterPlayer += 1
                } else {
                    counterPlayer = 0
                }
                
                if counterPlayer >= 2 {
                    break
                }
                
            }
            
            if counterPlayer < 2 {
                isNotClearPlayer = false
            } else {
                isNotClearPlayer = true
            }
            
            for dealerCards in dealerCards {
                
                if dealerCards == cardValue {
                    counterDealer += 1
                } else if dealerCards == cardSet {
                    counterDealer += 1
                } else {
                    counterDealer = 0
                }
                
                if counterDealer >= 2 {
                    break
                }
                
            }
            
            if counterDealer < 2 {
                isNotClearDealer = false
            } else {
                isNotClearDealer = true
            }
            
        }
        
        // assign to either the dealer or player card set
        if arrayPick == 1 {
            playerCards.append(cardValue)
            playerCards.append(cardSet)
            
            playerCardsStringArray.removeAll()
            var counterCard = 1
            for playerCard in playerCards {
                if counterCard.isMultiple(of: 2) {
                    playerCardsStringArray[(counterCard/2)-1] += "\(playerCard)"
                } else {
                    playerCardsStringArray.append("\(playerCard)")
                }
                counterCard+=1
            }
            
        } else {
            dealerCards.append(cardValue)
            dealerCards.append(cardSet)
        }
        
    }
    
    //find the max slide bet amount
    func getSlideBetAmount() -> Double{
        
        var returnAmount = 1
        
        if PlayerData().getMoney() >= 4000 {
            returnAmount = 4000
        } else {
            returnAmount = (PlayerData().getMoney()/2) + (PlayerData().getMoney()/4)+1
            
            if returnAmount != 1 {
                returnAmount = returnAmount - 1
            }
            
        }
        
        return Double(returnAmount)
        
    }
    
    
}
