//
//  Data.swift
//  GambleMan
//
//  Created by Bobby Dexter Wiles Jr. on 8/17/21.
//

import Foundation
import SwiftUI
import Combine


class AppDelegate: NSObject, UIApplicationDelegate {
    
    var lastTime = UserDefaults.standard.object(forKey: "lastTime")
    var currTime = Date()
    
    
    func applicationWillTerminate(_ application: UIApplication) {
        currTime = Date()
        UserDefaults.standard.set(currTime, forKey: "lastTime")
    }
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions lanuchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        if lastTime == nil {
            lastTime = currTime
            UserDefaults.standard.set(lastTime, forKey: "lastTime")
        }
        UserDefaults.standard.set(currTime, forKey: "currTime")
        
        return true
    }
}


class SlotData: ObservableObject {
    
    @Published public var SlotBox1 = 0
    @Published public var SlotBox2 = 0
    @Published public var SlotBox3 = 0
    @Published public var SlotWinningAmount = 0
    @Published public var spinDegree = 0.0
    @Published public var scale = 1
    
    var SlotIsSpin = false
    var SlotSpinTime = 10
    var SlotSpinCount = 0
    var SlotThreeRowRandom = 0
    var counter = 0
    
    
    func updateSlot(){
        
        if (!SlotIsSpin) {
            if (PlayerData().getMoney() >= 1000 && PlayerData().getMoney() <= 10000) {
                scale = 2
            } else if (PlayerData().getMoney() > 10000 && PlayerData().getMoney() <= 50000) {
                scale = 3
            } else if (PlayerData().getMoney() > 50000 && PlayerData().getMoney() <= 100000) {
                scale = 4
            } else if (PlayerData().getMoney() > 100000 && PlayerData().getMoney() <= 500000) {
                scale = 5
            } else if (PlayerData().getMoney() > 500000 && PlayerData().getMoney() <= 1000000) {
                scale = 6
            } else if (PlayerData().getMoney() > 1000000 && PlayerData().getMoney() <= 10000000) {
                scale = 7
            } else if (PlayerData().getMoney() > 10000000) {
                scale = 8
            } else {
                scale = 1
            }
        }
        
        
        if SlotIsSpin {
            
            SlotBox1 = Int.random(in: 1...7)
            SlotBox2 = Int.random(in: 1...7)
            SlotBox3 = Int.random(in: 1...7)
            
            if SlotSpinCount == SlotSpinTime {
                SlotIsSpin = false
                SlotThreeRowRandom = Int.random(in: 1...100)
                
                if SlotBox1 == 6 && SlotBox2 == 6 && SlotBox3 == 6 {
                    SlotBox1 = Int.random(in: 2...5)
                    SlotBox2 = Int.random(in: 1...7)
                    SlotBox3 = Int.random(in: 1...3)
                }
                
                if SlotThreeRowRandom <= 2 {
                    SlotBox1 = 7
                    SlotBox2 = 7
                    SlotBox3 = 7
                }
                if (SlotThreeRowRandom > 10) && (SlotThreeRowRandom <= 15) {
                    if SlotBox1 == 6 {
                        SlotBox1 = Int.random(in: 1...5)
                    }
                    SlotBox2 = SlotBox1
                    SlotBox3 = SlotBox1
                }
                
                SlotSpinEnd()
                
            }
            SlotSpinCount+=1
        }
        
        
        if (PlayerData().getMoney() >= 10) {
            spinDegree = 720
        } else {
            spinDegree = 0
        }
        
        
        
    }
    
    func SlotSpin(){
        if !SlotIsSpin {
            
            if PlayerData().getMoney() >= Int(pow(10.0, Double(scale))) {
                
                PlayerData().setMoney(amount: (PlayerData().getMoney() - Int(pow(10.0, Double(scale)))))
                
                SlotWinningAmount = 0
                SlotSpinCount = 0
                SlotIsSpin = true
                
                
            }
            
        }
    }
    
    
    func SlotSpinEnd(){
        if (SlotBox1 == 7) && (SlotBox2 == 7) && (SlotBox3 == 7) {
            SlotWinningAmount = (SlotWinningAmount + 500)*Int(pow(Double(scale), Double(scale)))
        } else if (SlotBox1 == SlotBox2) && (SlotBox1 == SlotBox3){
            SlotWinningAmount = (SlotWinningAmount + 200)*Int(pow(Double(scale), Double(scale)))
        } else if (SlotBox1 == SlotBox2) || (SlotBox1 == SlotBox3) || (SlotBox2 == SlotBox3) {
            SlotWinningAmount = (SlotWinningAmount + 50)*Int(pow(Double(scale), Double(scale)))
        }
        
        if (SlotWinningAmount >= 500) {
            counter += 1
            
            if (counter >= 4) {
                UserDefaults.standard.set(true, forKey: "IRS")
            }
        } else {
            if (Int.random(in: 1...100) <= 1) {
                counter -= 1
                
                if (counter < 0) {
                    counter = 0
                    UserDefaults.standard.set(false, forKey: "IRS")
                }
            }
        }
        
        PlayerData().setMoney(amount: PlayerData().getMoney() + SlotWinningAmount)
    }
    
}
