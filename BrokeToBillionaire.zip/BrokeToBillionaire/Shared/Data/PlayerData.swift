//
//  PlayerData.swift
//  GambleMan (iOS)
//
//  Created by Bobby Dexter Wiles Jr. on 8/17/21.
//

import Foundation
import SwiftUI
import Combine

class PlayerData: ObservableObject {
    @Published public var money = UserDefaults.standard.integer(forKey: "Money")
    @Published public var displayMoney = 0
    @Published public var isStart = false
    @Published public var titleY = 175.0
    @Published public var moveButton = 0
    //@Published public var IRS = UserDefaults.standard.bool(forKey: "IRS")
    var trigger1 = false
    var trigger2 = false
    var trigger3 = false
    
    
    //Achievment Data Here
    @Published public var moneyMakerAch = UserDefaults.standard.bool(forKey: "Ach1")
    @Published public var make1kAch = UserDefaults.standard.bool(forKey: "Ach2")
    @Published public var make1mAch = UserDefaults.standard.bool(forKey: "Ach3")
    @Published public var make1bAch = UserDefaults.standard.bool(forKey: "Ach4")
    @Published public var win10BlackJackGamesAch = UserDefaults.standard.bool(forKey: "Ach5")
    //@Published public var moneyMakerAch = UserDefaults.standard.bool(forKey: "Ach6")
    
    
    func getMoney() -> Int {
        return UserDefaults.standard.integer(forKey: "Money")
    }
    
    func setMoney(amount: Int) {
        money = amount
        UserDefaults.standard.set(money, forKey: "Money")
    }
    
    func startGrame() {
        UserDefaults.standard.set(false, forKey: "IRS")
        trigger1 = true
        trigger2 = true
        trigger3 = true
    }
    
    func moveTitle() {
        if (trigger1) {
            titleY -= (3)
            //moveButton += 3
            
            if (titleY <= -50) { //10 original
                trigger1 = false
            }
        }
        
        if (trigger2) {
            moveButton += (4)
            
            if (moveButton >= 375) {
                trigger2 = false
            }
        }
        
        if (trigger2 == false) && (trigger1 == false) && trigger3{
            isStart = true
        }
            
            
    }
    
}
