//
//  StockMarketData.swift
//  BrokeToBillionaire
//
//  Created by Bobby Dexter Wiles Jr. on 9/1/21.
//

import Foundation

class StockMarketData: ObservableObject {
    
    @Published public var xValue: [Int] = [0, (Int(ContentView().screenRect.width/10)), (Int(ContentView().screenRect.width/10))*2, (Int(ContentView().screenRect.width/10))*3, (Int(ContentView().screenRect.width/10))*4, (Int(ContentView().screenRect.width/10))*5, (Int(ContentView().screenRect.width/10))*6, (Int(ContentView().screenRect.width/10))*7, (Int(ContentView().screenRect.width/10))*8, (Int(ContentView().screenRect.width/10))*9]
    
    @Published public var heightValue: [Int] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 125]
    @Published public var sliderOrderStock = 0.0
    @Published public var sliderSellStock = 0.0
    @Published public var stockValue = 125
    @Published public var maxOwnStockAmount = 500
    @Published public var stockStoreageUpgradeCount = UserDefaults.standard.integer(forKey: "stockUpgrade");
    @Published public var ownedStockAmount = UserDefaults.standard.integer(forKey: "OwnedStock")
    @Published public var displaySellBar = false
    @Published public var displayBuyButton = false
    @Published public var displaySellButton = false
    
    func update() {
        
        var holderValue1 = 0
        var holderValue2 = 0
        
        stockValue += Int.random(in: -25 ... 25)
        
        if Int.random(in: 0...10) < 3 {
            if Int.random(in: 0...10) < 5 {
                stockValue = (stockValue/2) - stockValue
            } else {
                stockValue = (stockValue/2) + stockValue
            }
            
        }
        
        if maxOwnStockAmount*stockStoreageUpgradeCount == 0 {
            maxOwnStockAmount = 500
        } else {
            maxOwnStockAmount = 500 * (stockStoreageUpgradeCount+1)
        }
        
        if stockValue <= 0 {
            stockValue = 1
            stockValue = Int.random(in: 1...50)
        } else if stockValue > 250 {
            stockValue = 250
            
            stockValue += Int.random(in: -100 ... 0)
        }
        
        holderValue1 = stockValue
        
        for count in (0...9).reversed() {
            
            holderValue2 = heightValue[count]
            
            heightValue[count] = holderValue1
            
            holderValue1 = holderValue2
            
            
        }
        
        
        if ownedStockAmount > 0 {
            displaySellBar = true
        } else {
            sliderSellStock = 0
            displaySellBar = false
        }
        
        if sliderSellStock > 0 {
            displaySellButton = true
        } else {
            displaySellButton = false
        }
        
        if ((Int(sliderOrderStock) * stockValue) <= PlayerData().getMoney()) && (sliderOrderStock > 0) && (maxOwnStockAmount > ownedStockAmount) {
            displayBuyButton = true
        } else {
            displayBuyButton = false
        }
        
        
        
        UserDefaults.standard.set(ownedStockAmount, forKey: "OwnedStock")
        
    }
    
    func update2() {
        
        if ownedStockAmount > 0 {
            displaySellBar = true
        } else {
            sliderSellStock = 0
            displaySellBar = false
        }
        
        if sliderSellStock > 0 {
            displaySellButton = true
        } else {
            displaySellButton = false
        }
        
        if ((Int(sliderOrderStock) * stockValue) <= PlayerData().getMoney()) && (sliderOrderStock > 0) && (maxOwnStockAmount > ownedStockAmount) {
            displayBuyButton = true
        } else {
            displayBuyButton = false
        }
        
        
        
        UserDefaults.standard.set(ownedStockAmount, forKey: "OwnedStock")
        
    }
    
    func getBuySliderAmount() -> Double {
        let returnAmount = maxOwnStockAmount - ownedStockAmount
        
        if returnAmount < 1 {
            return 1.0
        }
        
        return Double(returnAmount)
    }
    
    func getSellSliderAmount() -> Double{
        if ownedStockAmount == 0 {
            return 1.0
        } else {
            return Double(ownedStockAmount)
        }
        
    }
    
    
    func buyStock() {
        
        if ((Int(sliderOrderStock) * stockValue) <= PlayerData().getMoney()) && (sliderOrderStock > 0) {
            
            PlayerData().setMoney(amount: PlayerData().getMoney() - (Int(sliderOrderStock) * stockValue))
            
            ownedStockAmount += Int(sliderOrderStock)
            
            UserDefaults.standard.set(ownedStockAmount, forKey: "OwnedStock")
            
            sliderOrderStock = 0
            
        }
        
        
    }
    
    func sellStock() {
        
        var profit = 0
        
        profit = Int(sliderSellStock) * stockValue
        
        ownedStockAmount -= Int(sliderSellStock)
        
        PlayerData().setMoney(amount: PlayerData().getMoney() + profit)
        
        sliderSellStock = 0
        
    }
    
    func upgradeStockStorage() {
        
        if ((maxOwnStockAmount * 30) <= PlayerData().getMoney()) {
            PlayerData().setMoney(amount: PlayerData().getMoney() - (maxOwnStockAmount * 30))
            stockStoreageUpgradeCount += 1
            UserDefaults.standard.set(stockStoreageUpgradeCount, forKey: "stockUpgrade")
        }
        
        
    }
    
    
}
