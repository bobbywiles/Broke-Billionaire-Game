//
//  GambleManApp.swift
//  Shared
//
//  Created by Bobby Dexter Wiles Jr. on 8/17/21.
//

import SwiftUI

@main
struct GambleManApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            
            ContentView()
                .colorScheme(.light)
            
        }
    }
}
